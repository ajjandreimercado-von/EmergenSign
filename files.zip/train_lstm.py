"""
train_lstm.py
--------------
Loads extracted landmark sequences (.npy files, one per rep, produced by
extract_landmarks.py), applies data augmentation (jittering + rotation per
Section 3.3.1), trains the stacked LSTM classifier, and converts the result
to TensorFlow Lite for offline Android deployment.

Expected folder layout (produced automatically by extract_landmarks.py):
    landmarks/
        chest_pain/
            signer01_chest_pain_rep1.npy   <- shape (30, 63)
            signer01_chest_pain_rep2.npy
            ...
        difficulty_breathing/
            ...
        ... (15 sign folders total)

USAGE once you have real extracted landmarks:
    python train_lstm.py --data ../landmarks --out ../models

USAGE right now, with zero real data (builds a synthetic dataset shaped
exactly like your real one will be, so you can confirm the LSTM trains,
augmentation runs, and TFLite conversion works before you've recorded
anything):
    python train_lstm.py --synthetic-test
"""

import os
import argparse
import numpy as np
import tensorflow as tf

# IMPORTANT: Keras 3's LSTM layer (the TensorFlow default as of TF 2.16+)
# produces NaN outputs when converted to TFLite -- its LSTM op does not
# lower cleanly into TFLite's fused LSTM kernel in current TF versions.
# tf_keras (the maintained legacy Keras 2 API) uses an LSTM implementation
# that DOES convert and run correctly on-device. Install with:
#     pip install tf_keras
import tf_keras as keras
from tf_keras import layers

SEQUENCE_LENGTH = 30
NUM_FEATURES = 63  # 21 landmarks x 3 coords

SIGN_CLASSES = [
    "chest_pain", "difficulty_breathing", "severe_headache", "dizzy",
    "stomach_pain", "nausea", "numbness", "blurry_vision", "palpitations",
    "chills", "fatigue", "sore_throat", "help", "doctor", "medicine",
]


# ---------------------------------------------------------------------
# 1. DATA AUGMENTATION  (Section 3.3.1: coordinate jittering + rotation)
# ---------------------------------------------------------------------
def jitter(sequence, sigma=0.01):
    """Adds small random spatial noise to each landmark position."""
    noise = np.random.normal(0, sigma, sequence.shape).astype(np.float32)
    return sequence + noise


def rotate(sequence, max_angle_deg=15):
    """Applies a random rotation (about the z-axis) to the hand coordinate frame."""
    angle = np.radians(np.random.uniform(-max_angle_deg, max_angle_deg))
    cos_a, sin_a = np.cos(angle), np.sin(angle)
    rot_matrix = np.array([[cos_a, -sin_a, 0],
                            [sin_a,  cos_a, 0],
                            [0,      0,     1]], dtype=np.float32)
    seq = sequence.reshape(SEQUENCE_LENGTH, 21, 3)
    seq = seq @ rot_matrix.T
    return seq.reshape(SEQUENCE_LENGTH, 63)


def augment_dataset(X, y, copies_per_sample=3):
    """For every real sequence, generate N augmented variants (jitter + rotate)."""
    aug_X, aug_y = [], []
    for seq, label in zip(X, y):
        aug_X.append(seq)          # keep original
        aug_y.append(label)
        for _ in range(copies_per_sample):
            variant = rotate(jitter(seq))
            aug_X.append(variant)
            aug_y.append(label)
    return np.array(aug_X, dtype=np.float32), np.array(aug_y)


# ---------------------------------------------------------------------
# 2. LOAD REAL DATA from the landmarks/ folder structure
# ---------------------------------------------------------------------
def load_dataset(data_dir):
    X, y = [], []
    classes_found = sorted(
        d for d in os.listdir(data_dir) if os.path.isdir(os.path.join(data_dir, d))
    )
    if not classes_found:
        raise ValueError(f"No sign folders found in {data_dir}. Run extract_landmarks.py first.")

    for label in classes_found:
        class_dir = os.path.join(data_dir, label)
        for fname in os.listdir(class_dir):
            if fname.endswith(".npy"):
                seq = np.load(os.path.join(class_dir, fname))
                if seq.shape != (SEQUENCE_LENGTH, NUM_FEATURES):
                    print(f"Skipping {fname}: unexpected shape {seq.shape}")
                    continue
                X.append(seq)
                y.append(label)
    return np.array(X, dtype=np.float32), np.array(y), classes_found


# ---------------------------------------------------------------------
# 3. SYNTHETIC DATA (for testing the pipeline before real recordings exist)
# ---------------------------------------------------------------------
def make_synthetic_dataset(n_classes=15, reps_per_class=30, seed=42):
    """
    Builds a fake dataset shaped exactly like your real one will be:
    15 classes x 30 sequences x (30 frames, 63 features).
    Each class gets a distinct underlying motion pattern so the LSTM has
    something learnable to distinguish -- this proves the training code
    works correctly, independent of your real data quality.
    """
    rng = np.random.default_rng(seed)
    X, y = [], []
    classes = SIGN_CLASSES[:n_classes]
    for class_idx, label in enumerate(classes):
        # each class gets its own frequency/phase "signature" motion
        freq = 1 + class_idx * 0.3
        phase = class_idx * 0.5
        for _rep in range(reps_per_class):
            t = np.linspace(0, 2 * np.pi, SEQUENCE_LENGTH)
            base_motion = np.sin(freq * t + phase)
            seq = np.zeros((SEQUENCE_LENGTH, NUM_FEATURES), dtype=np.float32)
            for feat in range(NUM_FEATURES):
                seq[:, feat] = base_motion * (0.5 + 0.05 * feat) 
            seq += rng.normal(0, 0.02, seq.shape)  # natural per-rep variation
            X.append(seq)
            y.append(label)
    return np.array(X, dtype=np.float32), np.array(y), classes


# ---------------------------------------------------------------------
# 4. MODEL  (stacked LSTM, per Section 2.1 / 3.3.2)
# ---------------------------------------------------------------------
def build_lstm_model(num_classes):
    # unroll=True avoids TFLite's dynamic tf.while/TensorList path, which is
    # both unsupported by the standard converter and, even when it does
    # convert, has caused runtime "variable != nullptr" crashes on-device
    # with Keras 3. Safe to unroll here since SEQUENCE_LENGTH is small (30)
    # and fixed -- the extra graph size is negligible for this model.
    model = keras.Sequential([
        layers.Input(shape=(SEQUENCE_LENGTH, NUM_FEATURES)),
        layers.LSTM(64, return_sequences=True, unroll=True),
        layers.Dropout(0.3),
        layers.LSTM(32, unroll=True),
        layers.Dropout(0.3),
        layers.Dense(32, activation="relu"),
        layers.Dense(num_classes, activation="softmax"),
    ])
    model.compile(
        optimizer=keras.optimizers.Adam(learning_rate=1e-3),
        loss="sparse_categorical_crossentropy",
        metrics=["accuracy"],
    )
    return model


# ---------------------------------------------------------------------
# 5. TRAIN + EVALUATE + CONVERT TO TFLITE
# ---------------------------------------------------------------------
def run_pipeline(X_raw, y_raw, classes, out_dir, epochs=20, copies_per_sample=3):
    os.makedirs(out_dir, exist_ok=True)
    label_to_idx = {c: i for i, c in enumerate(classes)}
    y_idx = np.array([label_to_idx[l] for l in y_raw])

    print(f"Raw dataset: {X_raw.shape[0]} sequences across {len(classes)} classes")

    # --- augmentation ---
    X_aug, y_aug = augment_dataset(X_raw, y_idx, copies_per_sample=copies_per_sample)
    print(f"After augmentation: {X_aug.shape[0]} sequences "
          f"({copies_per_sample} extra variants generated per real sample)")

    # --- train / validation split ---
    n = X_aug.shape[0]
    idx = np.random.permutation(n)
    split = int(n * 0.8)
    train_idx, val_idx = idx[:split], idx[split:]
    X_train, y_train = X_aug[train_idx], y_aug[train_idx]
    X_val, y_val = X_aug[val_idx], y_aug[val_idx]

    # --- train ---
    model = build_lstm_model(num_classes=len(classes))
    history = model.fit(
        X_train, y_train,
        validation_data=(X_val, y_val),
        epochs=epochs,
        batch_size=16,
        verbose=2,
    )

    val_acc = history.history["val_accuracy"][-1]
    val_loss = history.history["val_loss"][-1]
    print(f"\nFinal validation accuracy: {val_acc:.3f}  |  loss: {val_loss:.3f}")

    # --- save Keras model ---
    keras_path = os.path.join(out_dir, "fsl_lstm_model.keras")
    model.save(keras_path)
    print(f"Saved Keras model: {keras_path}")

    # --- convert to TFLite (Section 3.3.2: post-training quantization) ---
    # Fixed batch size of 1 (on-device inference is always one sequence at a
    # time) combined with unroll=True on the LSTM layers above avoids both
    # the converter-time TensorListReserve error and the runtime
    # "variable != nullptr" crash seen with the dynamic-loop LSTM path.
    run_model = tf.function(lambda x: model(x))
    concrete_func = run_model.get_concrete_function(
        tf.TensorSpec([1, SEQUENCE_LENGTH, NUM_FEATURES], tf.float32)
    )
    converter = tf.lite.TFLiteConverter.from_concrete_functions([concrete_func], model)
    converter.optimizations = [tf.lite.Optimize.DEFAULT]
    tflite_model = converter.convert()
    tflite_path = os.path.join(out_dir, "fsl_lstm_quantized.tflite")
    with open(tflite_path, "wb") as f:
        f.write(tflite_model)

    orig_size_kb = os.path.getsize(keras_path) / 1024
    tflite_size_kb = os.path.getsize(tflite_path) / 1024
    print(f"Saved TFLite model: {tflite_path}")
    print(f"Size: Keras {orig_size_kb:.1f} KB -> TFLite {tflite_size_kb:.1f} KB "
          f"({100 * (1 - tflite_size_kb / orig_size_kb):.0f}% reduction)")

    # save class label mapping (the app needs this to map prediction index -> sign text)
    labels_path = os.path.join(out_dir, "class_labels.txt")
    with open(labels_path, "w") as f:
        f.write("\n".join(classes))
    print(f"Saved class labels: {labels_path}")

    return model, val_acc


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", type=str, default="../landmarks")
    parser.add_argument("--out", type=str, default="../models")
    parser.add_argument("--epochs", type=int, default=20)
    parser.add_argument("--synthetic-test", action="store_true",
                         help="Run the full pipeline on fake data shaped like your real dataset")
    args = parser.parse_args()

    if args.synthetic_test:
        print("=== SYNTHETIC TEST MODE (no real recordings needed) ===\n")
        X, y, classes = make_synthetic_dataset()
        run_pipeline(X, y, classes, args.out, epochs=args.epochs)
    else:
        X, y, classes = load_dataset(args.data)
        run_pipeline(X, y, classes, args.out, epochs=args.epochs)
