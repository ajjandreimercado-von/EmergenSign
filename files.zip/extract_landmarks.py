"""
extract_landmarks.py
---------------------
Extracts 21 3D hand landmarks per frame from a video using MediaPipe's
current HandLandmarker (Tasks API), normalizes them relative to the wrist,
and saves 30-frame sequences ready for LSTM training.

Matches Section 3.3.1 of the FSL-Emergency methodology:
  - 21 landmarks x (x, y, z) = 63 features per frame
  - 30-frame temporal window (~1 second at 30fps)
  - wrist-relative normalization for scale/translation invariance
  - confidence-threshold gate to reject unreliable frames
  - supports multi-rep videos (Option B recording style) by auto-splitting
    on pauses where no hand is detected

ONE-TIME SETUP (run this once, needs internet):
    mkdir -p mp_models
    curl -L -o mp_models/hand_landmarker.task \
      https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task

USAGE once you have real recordings:
    python extract_landmarks.py --video raw_videos/signer01_chestpain.mp4 \
        --sign chest_pain --signer signer01 --out ../landmarks
"""

import os
import argparse
import numpy as np
import cv2
import mediapipe as mp
from mediapipe.tasks import python as mp_python
from mediapipe.tasks.python import vision

SEQUENCE_LENGTH = 30
NUM_LANDMARKS = 21
NUM_COORDS = 3
CONFIDENCE_THRESHOLD = 0.5
MODEL_PATH = os.path.join(os.path.dirname(__file__), "..", "mp_models", "hand_landmarker.task")


def build_landmarker(model_path=MODEL_PATH, min_confidence=CONFIDENCE_THRESHOLD):
    base_options = mp_python.BaseOptions(model_asset_path=model_path)
    options = vision.HandLandmarkerOptions(
        base_options=base_options,
        running_mode=vision.RunningMode.VIDEO,
        num_hands=1,
        min_hand_detection_confidence=min_confidence,
        min_tracking_confidence=min_confidence,
    )
    return vision.HandLandmarker.create_from_options(options)


def normalize_wrist_relative(landmarks_xyz):
    """21x3 array -> normalized relative to wrist (landmark 0)."""
    wrist = landmarks_xyz[0].copy()
    return landmarks_xyz - wrist


def extract_landmarks_from_video(video_path, min_confidence=CONFIDENCE_THRESHOLD):
    """
    Returns (sequences, rejected_frame_count)
    sequences: list of (30, 63) float32 arrays, one per rep found in the video
    """
    if not os.path.exists(MODEL_PATH):
        raise FileNotFoundError(
            f"Model file not found at {MODEL_PATH}.\n"
            "Run the one-time setup step in this script's docstring first "
            "(downloads ~10MB from Google, needs internet, only once)."
        )

    landmarker = build_landmarker(min_confidence=min_confidence)
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        raise FileNotFoundError(f"Could not open video: {video_path}")

    fps = cap.get(cv2.CAP_PROP_FPS) or 30
    all_frames = []
    rejected = 0
    frame_idx = 0

    while True:
        ret, frame = cap.read()
        if not ret:
            break
        frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        mp_image = mp.Image(image_format=mp.ImageFormat.SRGB, data=frame_rgb)
        timestamp_ms = int((frame_idx / fps) * 1000)
        result = landmarker.detect_for_video(mp_image, timestamp_ms)

        if result.hand_landmarks:
            hand = result.hand_landmarks[0]
            coords = np.array([[lm.x, lm.y, lm.z] for lm in hand], dtype=np.float32)
            coords = normalize_wrist_relative(coords)
            all_frames.append(coords.flatten())
        else:
            all_frames.append(None)
            rejected += 1
        frame_idx += 1

    cap.release()
    landmarker.close()

    # split into reps using "no hand detected" gaps as pause markers
    sequences = []
    current_run = []
    for f in all_frames:
        if f is not None:
            current_run.append(f)
        else:
            if len(current_run) >= SEQUENCE_LENGTH:
                sequences.append(_fit_to_length(current_run, SEQUENCE_LENGTH))
            current_run = []
    if len(current_run) >= SEQUENCE_LENGTH:
        sequences.append(_fit_to_length(current_run, SEQUENCE_LENGTH))

    return sequences, rejected


def _fit_to_length(frame_list, target_len):
    arr = np.array(frame_list, dtype=np.float32)
    n = arr.shape[0]
    if n == target_len:
        return arr
    idx = np.linspace(0, n - 1, target_len).astype(int)
    return arr[idx]


def save_sequences(sequences, sign_label, out_dir, signer_id="signer00"):
    os.makedirs(os.path.join(out_dir, sign_label), exist_ok=True)
    saved_paths = []
    for i, seq in enumerate(sequences):
        fname = f"{signer_id}_{sign_label}_rep{i+1}.npy"
        path = os.path.join(out_dir, sign_label, fname)
        np.save(path, seq)
        saved_paths.append(path)
    return saved_paths


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--video", type=str, help="Path to input video file")
    parser.add_argument("--sign", type=str, help="Sign label, e.g. chest_pain")
    parser.add_argument("--signer", type=str, default="signer00")
    parser.add_argument("--out", type=str, default="../landmarks")
    args = parser.parse_args()

    if not args.video or not args.sign:
        raise SystemExit("Provide --video and --sign")

    sequences, rejected = extract_landmarks_from_video(args.video)
    print(f"Found {len(sequences)} clean sequences, rejected {rejected} low-confidence frames")
    paths = save_sequences(sequences, args.sign, args.out, args.signer)
    for p in paths:
        print("Saved:", p)
